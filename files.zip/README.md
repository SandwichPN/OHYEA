# OHYEA.cz 🍊

Oranžový herní koutek se třemi minihrami: Kliker, Pexeso a Kvíz.

## Jak to dostat na GitHub Pages

1. Na GitHubu vytvoř nový repozitář, např. `ohyea`.
2. Nahraj do něj všechny soubory z téhle složky: `index.html`, `style.css`, `kliker.html`, `pexeso.html`, `kviz.html`.
3. V repozitáři jdi do **Settings → Pages**.
4. U „Build and deployment" nastav Source: **Deploy from a branch**, branch **main**, složka **/ (root)** → Save.
5. Po pár minutách poběží web na `https://tvuj-ucet.github.io/ohyea/`.

## Vlastní doména ohyea.cz

1. U registrátora domény přidej DNS záznam typu **CNAME** směřující na `tvuj-ucet.github.io` (nebo A záznamy na GitHubovy IP adresy, pokud chceš apex doménu bez `www`).
2. V repozitáři v **Settings → Pages** vyplň pole **Custom domain** hodnotou `ohyea.cz` a ulož.
3. Počkej na ověření DNS (může trvat pár hodin) — GitHub ti dá vědět, až bude vše zelené.

## Co si můžeš upravit

- Barvy a fonty jsou v `style.css` jako proměnné nahoře (`--orange-600` a spol.).
- Každá hra je samostatný soubor — klidně přidej další (stačí zkopírovat vzor a přidat novou kartu do `index.html`).
